<?php
include "Conexion_TiendaElectro.php";

$Query= "SELECT * FROM proveedor";
$Resultado= mysqli_Query($Conexion,$Query) or die("Error al cargar".mysqli_error());

echo "<table style=\"border: 3px solid grey\">";
   echo "<tr style=\"border: 2px solid grey\"bgcolor=\"sky blue\">";

      echo "<td> Proveedor </td>";
      echo "<td> Direccion </td>";
      echo"<td> Contacto </tr>";
      echo"</tr>";

$Bandera="0";
while ($registro=mysqli_fetch_array($Resultado))
{
    if($Bandera==1)
    {
        echo "<tr style=\"border:2px spolid grey\"bgcolor=\"#8398f7\">";
       
        echo "<td>".$registro[1]." "."</td>";
        echo "<td>".$registro[2]." "."</td>";
        echo "<td>".$registro[3]." "."</td>";
        echo "</td>";

         $Bandera="0";
        }
        else
        {
            echo "<tr style=\"border:2px spolid grey\"bgcolor=\"#8398f7\">";
    
            echo "<td>".$registro[1]." "."</td>";
            echo "<td>".$registro[2]." "."</td>"; 
            echo "<td>".$registro[3]." "."</td>"; 

            $Bandera="1";

        }

        echo "</tr>";
}
echo "</table>";

mysqli_close($Conexion);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<br>
       <a href="Electronica-Tienda.html"><input type="reset" value="VOLVER"></a>
    <br>


</body>
</html>