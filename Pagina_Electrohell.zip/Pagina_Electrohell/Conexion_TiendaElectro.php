<?php

$servername = "localhost";  // Nombre del servidor de la base de datos
$username = "root";  // Nombre de usuario de la base de datos
$password = "";  // Contraseña de la base de datos
$dbname = "electronica";  // Nombre de la base de datos

// Crear la conexión
$Conexion = mysqli_connect($servername, $username, $password, $dbname);

?>